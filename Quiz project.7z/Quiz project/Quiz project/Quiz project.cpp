// Quiz project.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include "Menu.h"
using namespace std;


int main()
{
	string i;
	Menu menu;
	menu.display();
	return 0;
}

