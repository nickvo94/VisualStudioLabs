#include "stdafx.h"
#include "Observe_interf.h"
#include "LimitedCounter.h"
#include <iostream>

using namespace std;

